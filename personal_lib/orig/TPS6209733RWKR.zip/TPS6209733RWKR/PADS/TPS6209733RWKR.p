*PADS-LIBRARY-PART-TYPES-V9*

TPS6209733RWKR RWK0011B_1 I ANA 6 1 0 0 0
TIMESTAMP 2025.03.27.07.48.59
"Mouser Part Number" 595-TPS6209733RWKR
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=595-TPS6209733RWKR
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS6209733RWKR
"Description" 2-A Step Down Converter with Selectable Switching Frequency in HotRod package
"Datasheet Link" http://www.ti.com/lit/ds/symlink/tps62097.pdf
GATE 1 11 0
TPS6209733RWKR
1 0 U PGND
2 0 U SW
3 0 U VOS
4 0 U FB
5 0 U PG
6 0 U EN
7 0 U PVIN
8 0 U AVIN
9 0 U SS/TR
10 0 U MODE
11 0 U AGND

*END*
*REMARK* SamacSys ECAD Model
574625/449296/2.50/11/4/Integrated Circuit
