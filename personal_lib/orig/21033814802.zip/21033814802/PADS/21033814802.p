*PADS-LIBRARY-PART-TYPES-V9*

21033814802 21033814802 I CON 9 1 0 0 0
TIMESTAMP 2025.03.10.11.21.43
"Manufacturer_Name" HARTING
"Manufacturer_Part_Number" 21033814802
"Mouser Part Number" 617-21033814802
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/HARTING/21033814802?qs=%252BTm8HPXHDaLxT5w5VYKkcw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" M12 X-code 8pin female PCB with front panel mounting, angled, Cat6A  (w/ housing 21033012003)
"Datasheet Link" https://b2b.harting.com/files/download/PRD/PDF_DS/PDF_DS_21033814802_EN.pdf
"Geometry.Height" 21mm
GATE 1 9 0
21033814802
1 0 U TD1+
2 0 U RD1-
3 0 U TD2+
4 0 U RD2-
5 0 U TD4+
6 0 U RD4-
7 0 U RD3-
8 0 U TD3+
MH1 0 U MH1

*END*
*REMARK* SamacSys ECAD Model
901063/449296/2.50/9/2/Connector
