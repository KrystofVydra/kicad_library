*PADS-LIBRARY-PART-TYPES-V9*

PAC1954T-E_4MX QFN50P300X300X90-17N-D I ANA 7 1 0 0 0
TIMESTAMP 2025.02.26.15.04.18
"Mouser Part Number" 579-PAC1954T-E/4MX
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/PAC1954T-E-4MX?qs=W%2FMpXkg%252BdQ5Udsy1uGluGA%3D%3D
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" PAC1954T-E/4MX
"Description" Current & Power Monitors & Regulators Quad High-Side Current Sensor, I2C/SMBus, 2 Alerts, 32V
"Datasheet Link" 
"Geometry.Height" 0.9mm
GATE 1 17 0
PAC1954T-E_4MX
1 0 B 1
2 0 B 2
3 0 B 3
4 0 B 4
5 0 B 5
6 0 B 6
7 0 B 7
8 0 B 8
12 0 B 12
11 0 B 11
10 0 B 10
9 0 B 9
17 0 B 17
16 0 B 16
15 0 B 15
14 0 B 14
13 0 B 13

*END*
*REMARK* SamacSys ECAD Model
15579464/449296/2.50/17/4/Integrated Circuit
