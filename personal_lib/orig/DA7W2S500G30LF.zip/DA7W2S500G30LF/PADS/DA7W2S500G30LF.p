*PADS-LIBRARY-PART-TYPES-V9*

DA7W2S500G30LF DA7W2S500G30LF I CON 7 1 0 0 0
TIMESTAMP 2025.02.26.16.36.09
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Amphenol Communications Solutions
"Manufacturer_Part_Number" DA7W2S500G30LF
"Description" Mixed Signal and Power 7W2 Socket Right Angle Solder 30A, Europe Standard, 200 Cycles, Front:Without Accessory, Back:Harpoons for 1.6mm PCB Thickness.
"Datasheet Link" https://cdn.amphenol-cs.com/media/wysiwyg/files/drawing/c01-8639-2300.pdf
"Geometry.Height" 13.815mm
GATE 1 9 0
DA7W2S500G30LF
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U MH1
7 0 U MH2
A1 0 U A1
A2 0 U A2

*END*
*REMARK* SamacSys ECAD Model
18755213/449296/2.50/9/2/Connector
