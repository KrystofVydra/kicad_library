*PADS-LIBRARY-PART-TYPES-V9*

3007W2SCT56N40X 3007W2SCT56N40X I CON 9 1 0 0 0
TIMESTAMP 2025.03.11.11.05.50
"Manufacturer_Name" CONEC
"Manufacturer_Part_Number" 3007W2SCT56N40X
"Mouser Part Number" 706-3007W2SCT56N40X
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/CONEC/3007W2SCT56N40X?qs=1A3x81zjaSzyTiDHCxUfpA%3D%3D
"Arrow Part Number" 3007W2SCT56N40X
"Arrow Price/Stock" https://www.arrow.com/en/products/3007w2sct56n40x/conec?region=nac
"Description" D-Sub Mixed Contact Connectors 7W2 SOLDER CUP FEMALE R/A 20 AMP
"Datasheet Link" https://media.digikey.com/pdf/Data%20Sheets/Conec%20PDFs/3007W2SCT56N40X_Dwg.pdf
"Geometry.Height" 12mm
GATE 1 9 0
3007W2SCT56N40X
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9

*END*
*REMARK* SamacSys ECAD Model
851602/449296/2.50/9/4/Connector
