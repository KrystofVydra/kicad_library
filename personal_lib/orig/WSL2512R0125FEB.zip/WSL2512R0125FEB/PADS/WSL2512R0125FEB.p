*PADS-LIBRARY-PART-TYPES-V9*

WSL2512R0125FEB RESC6432X89N I RES 7 1 0 0 0
TIMESTAMP 2025.02.26.15.55.32
"Mouser Part Number" 71-WSL2512R0125FEB
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Vishay-Dale/WSL2512R0125FEB?qs=9V8pwCp4J4BL%2FbD9OORFig%3D%3D
"Manufacturer_Name" Vishay
"Manufacturer_Part_Number" WSL2512R0125FEB
"Description" Current Sense Resistors - SMD 1watt .0125ohms 1%
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/WSL2512R0125FEB.pdf
"Geometry.Height" 0.889mm
GATE 1 2 0
WSL2512R0125FEB
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
1634754/449296/2.50/2/3/Resistor
