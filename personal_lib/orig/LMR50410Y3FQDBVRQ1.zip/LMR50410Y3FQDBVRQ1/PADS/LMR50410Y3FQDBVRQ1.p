*PADS-LIBRARY-PART-TYPES-V9*

LMR50410Y3FQDBVRQ1 SOT95P280X145-6N I ANA 7 1 0 0 0
TIMESTAMP 2025.02.23.10.25.26
"Mouser Part Number" 595-R50410Y3FQDBVRQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/LMR50410Y3FQDBVRQ1?qs=81r%252BiQLm7BTaIXwCgdOuiA%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LMR50410Y3FQDBVRQ1
"Description" LMR50410Y3FQDBVRQ1
"Datasheet Link" https://www.ti.com/lit/ds/symlink/lmr50410-q1.pdf?ts=1611309677669
"Geometry.Height" 1.45mm
GATE 1 6 0
LMR50410Y3FQDBVRQ1
1 0 U CB
2 0 U GND
3 0 U FB
6 0 U SW
5 0 U VIN
4 0 U EN

*END*
*REMARK* SamacSys ECAD Model
13360662/449296/2.50/6/3/Integrated Circuit
