*PADS-LIBRARY-PART-TYPES-V9*

BSS138LT3G SOT96P237X111-3N I TRX 7 1 0 0 0
TIMESTAMP 2025.02.23.16.21.28
"Mouser Part Number" 863-BSS138LT3G
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/onsemi/BSS138LT3G?qs=vNc2DXHODiIFTBAtRV5T3Q%3D%3D
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" BSS138LT3G
"Description" Low Threshold Voltage; Miniature SOT-23 Surface Mount Package; RoHS Compliant
"Datasheet Link" https://www.onsemi.com/pub/Collateral/BSS138LT1-D.PDF
"Geometry.Height" 1.11mm
GATE 1 3 0
BSS138LT3G
1 0 U G
3 0 U D
2 0 U S

*END*
*REMARK* SamacSys ECAD Model
224526/449296/2.50/3/2/MOSFET (N-Channel)
