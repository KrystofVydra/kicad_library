*PADS-LIBRARY-PART-TYPES-V9*

0533984002 0533984002 I CON 9 1 0 0 0
TIMESTAMP 2026.02.03.14.11.55
"Manufacturer_Name" Molex
"Manufacturer_Part_Number" 0533984002
"Mouser Part Number" N/A
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Molex/0533984002?qs=eP2BKZSCXI6Unul8tn%252B63Q%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" 1.25mm Pitch, PicoBlade PCB Header, Single Row, Vertical, Surface Mount,  Gold Flash Plating, 2 Circuits, Tape and Reel
"Datasheet Link" https://www.molex.com/en-us/products/part-detail-pdf/533984002?display=pdf
"Geometry.Height" 4.9mm
GATE 1 4 0
0533984002
1 0 U 1
2 0 U 2
MP1 0 U MP1
MP2 0 U MP2

*END*
*REMARK* SamacSys ECAD Model
15028795/449296/2.50/4/2/Connector
