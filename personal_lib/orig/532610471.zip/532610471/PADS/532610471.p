*PADS-LIBRARY-PART-TYPES-V9*

532610471 532610471 I CON 9 1 0 0 0
TIMESTAMP 2025.04.07.07.14.48
"Manufacturer_Name" Molex
"Manufacturer_Part_Number" 532610471
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 532610471
"Arrow Price/Stock" https://www.arrow.com/en/products/53261-0471/molex?region=nac
"Description" 1.25mm Pitch, PicoBlade PCB Header, Single Row, Right-Angle, Surface Mount, Tin (Sn) Plating, Friction Lock, 4 Circuits, Tape and Reel
"Datasheet Link" https://www.molex.com/pdm_docs/sd/532610271_sd.pdf
"Geometry.Height" 3.4mm
GATE 1 4 0
532610471
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4

*END*
*REMARK* SamacSys ECAD Model
13495286/449296/2.50/4/2/Connector
