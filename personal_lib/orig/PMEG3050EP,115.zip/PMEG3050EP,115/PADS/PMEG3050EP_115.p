*PADS-LIBRARY-PART-TYPES-V9*

PMEG3050EP_115 PMEG3050EP115 I DIO 7 1 0 0 0
TIMESTAMP 2025.04.07.14.34.17
"Mouser Part Number" 771-PMEG3050EP115
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/PMEG3050EP115?qs=GcY6OjH1zdmnjQ%2FhUT5aOA%3D%3D
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" PMEG3050EP,115
"Description" NXP PMEG3050EP,115 SMT Schottky Diode, 30V 5A, 2-Pin SOD-128
"Datasheet Link" https://assets.nexperia.com/documents/data-sheet/PMEG3050EP.pdf
"Geometry.Height" 1mm
GATE 1 2 0
PMEG3050EP_115
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
1278451/449296/2.50/2/2/Schottky Diode
