*PADS-LIBRARY-PART-TYPES-V9*

53398-0471 533980471 I CON 9 1 0 0 0
TIMESTAMP 2025.04.03.13.40.19
"Manufacturer_Name" Molex
"Manufacturer_Part_Number" 53398-0471
"Mouser Part Number" 538-53398-0471
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Molex/53398-0471?qs=yqtfsgZKt1SrARkpB7YBSw%3D%3D
"Arrow Part Number" 53398-0471
"Arrow Price/Stock" https://www.arrow.com/en/products/53398-0471/molex?region=nac
"Description" 4 way straight SMT header,1.25mm pitch Molex PICOBLADE Series, Series Number 53398, 1.25mm Pitch 4 Way 1 Row Straight PCB Header, Solder Termination, 1A
"Datasheet Link" http://www.molex.com/webdocs/datasheets/pdf/en-us/0533980471_PCB_HEADERS.pdf
"Geometry.Height" 4mm
GATE 1 6 0
53398-0471
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6

*END*
*REMARK* SamacSys ECAD Model
258264/449296/2.50/6/4/Connector
