*PADS-LIBRARY-PART-TYPES-V9*

CSD17576Q5B CSD17576Q5B I TRX 7 1 0 0 0
TIMESTAMP 2025.03.19.08.57.31
"Mouser Part Number" 595-CSD17576Q5B
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/CSD17576Q5B?qs=NRIcxvoDUtdp95E8PySMAA%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" CSD17576Q5B
"Description" CSD17576Q5B, 30-V N-Cannel NexFET Power MOSFET
"Datasheet Link" http://www.ti.com/lit/gpn/csd17576q5b
"Geometry.Height" 1.05mm
GATE 1 9 0
CSD17576Q5B
1 0 U S_1
2 0 U S_2
3 0 U S_3
4 0 U G
5 0 U D_1
6 0 U D_2
7 0 U D_3
8 0 U D_4
9 0 U D_5

*END*
*REMARK* SamacSys ECAD Model
725510/449296/2.50/9/0/MOSFET (N-Channel)
