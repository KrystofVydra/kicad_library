*PADS-LIBRARY-PART-TYPES-V9*

LD09S13A4GX00LF LD09S13A4GX00LF I CON 9 1 0 0 0
TIMESTAMP 2025.02.25.12.47.19
"Manufacturer_Name" Amphenol Communications Solutions
"Manufacturer_Part_Number" LD09S13A4GX00LF
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" LD09S13A4GX00LF
"Arrow Price/Stock" https://www.arrow.com/en/products/ld09s13a4gx00lf/amphenol-fci?region=nac
"Description" D-Subminiature Economy Range, Input Output Connectors, Signal 9 way Socket Right Angle, Solder Europe standard, 50 cycles, Harpoons + Threaded Insert UNC 4 - 40 + Elec cont., 1.6 mm PCB thickness
"Datasheet Link" https://cdn.amphenol-cs.com/media/wysiwyg/files/drawing/10130913.pdf
"Geometry.Height" 13.86mm
GATE 1 11 0
LD09S13A4GX00LF
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U MH1
11 0 U MH2

*END*
*REMARK* SamacSys ECAD Model
18853002/449296/2.50/11/3/Connector
