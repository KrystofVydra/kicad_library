*PADS-LIBRARY-PART-TYPES-V9*

TAJE227K016RNJV CAPPM7344X430N I CAP 7 1 0 0 0
TIMESTAMP 2025.03.20.09.20.55
"Mouser Part Number" 581-TAJE227K016RNJV
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/KYOCERA-AVX/TAJE227K016RNJV?qs=G2E3TvrFun0eH%252BLtG%252Bfp8Q%3D%3D
"Manufacturer_Name" Kyocera AVX
"Manufacturer_Part_Number" TAJE227K016RNJV
"Description" Tantalum Capacitors - Solid SMD 16volts 220uF 10%
"Datasheet Link" http://datasheets.avx.com/TAJ.pdf
"Geometry.Height" 4.3mm
GATE 1 2 0
TAJE227K016RNJV
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
1790970/449296/2.50/2/5/Capacitor Polarised
