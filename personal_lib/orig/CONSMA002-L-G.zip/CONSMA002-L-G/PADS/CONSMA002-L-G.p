*PADS-LIBRARY-PART-TYPES-V9*

CONSMA002-L-G CONSMA002LG I CON 7 1 0 0 0
TIMESTAMP 2025.04.07.07.56.46
"Mouser Part Number" N/A
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/TE-Connectivity/CONSMA002-L-G?qs=ulEaXIWI0c%2F4k%2FACIjdiXw%3D%3D
"Manufacturer_Name" TE Connectivity
"Manufacturer_Part_Number" CONSMA002-L-G
"Description" Body Features: Cable Connector Orientation Right Angle | Body Material Finish Plated | Body Plating Material Gold | Body Material Brass | Configuration Features: Number of Positions 1 | Number of Coaxial Contacts 1 | PCB Mount Orientation Right Angle | Contact Features: RF Connector Center Contact Plating Material Gold | RF Connector Center Contact Material Beryllium Copper | Electrical Characteristics: Impedance 50 OHM | Mechanical Attachment: RF Connector Coupling Mechanism Threaded | Detent Without | RF 
"Datasheet Link" https://www.te.com/commerce/DocumentDelivery/DDEController?Action=srchrtrv&DocNm=CONSMA002-L-G&DocType=Data%20Sheet&DocLang=English&PartCntxt=CONSMA002-L-G&DocFormat=pdf
"Geometry.Height" 10.4mm
GATE 1 5 0
CONSMA002-L-G
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5

*END*
*REMARK* SamacSys ECAD Model
18067278/449296/2.50/5/2/Connector
