*PADS-LIBRARY-PART-TYPES-V9*

BQ25758RRVR QFN50P500X600X100-37N-D I ANA 9 1 0 0 0
TIMESTAMP 2025.07.10.12.07.50
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" BQ25758RRVR
"Mouser Part Number" 595-BQ25758RRVR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/BQ25758RRVR?qs=dbcCsuKDzFU%252B3snfDn9Cwg%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Battery Management IC controlled 60-V bi-directional buck-boost controller with USB PD EPR and PPS support 36-VQFN -40 to 85
"Datasheet Link" https://www.ti.com/lit/ds/symlink/bq25758.pdf?ts=1715635168867&ref_url=https%253A%252F%252Fwww.mouser.com%252F
"Geometry.Height" 1mm
GATE 1 37 0
BQ25758RRVR
1 0 U SCL
2 0 U SDA
3 0 U \INT
4 0 U STAT
5 0 U NC_1
6 0 U \PG
7 0 U \CE
8 0 U TS_/_NC
9 0 U IOUT
10 0 U IIN
11 0 U NC_2
12 0 U VO__SNS
13 0 U SRN
14 0 U SRP
15 0 U NC_3
16 0 U NC_4
17 0 U MODE
18 0 U SW2
28 0 U SW1
27 0 U HIDRV1
26 0 U BTST1
25 0 U LODRV1
24 0 U REGN
23 0 U DRV_SUP
22 0 U PGND_1
21 0 U LODRV2
20 0 U BTST2
19 0 U HIDRV2
37 0 U PGND_2
36 0 U FSW__SYNC
35 0 U ACOV
34 0 U ACUV
33 0 U VAC_2
32 0 U VAC_1
31 0 U NC_5
30 0 U ACP
29 0 U ACN

*END*
*REMARK* SamacSys ECAD Model
19605102/449296/2.50/37/3/Integrated Circuit
