*PADS-LIBRARY-PART-TYPES-V9*

CMS04_TE12L_Q_M_ SODFL4724X108N I DIO 7 1 0 0 0
TIMESTAMP 2025.02.27.14.54.43
"Mouser Part Number" 757-CMS04TE12L,Q,M
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Toshiba/CMS04TE12LQM?qs=3oXjESXZBsCiyX2tZScGOQ%3D%3D
"Manufacturer_Name" Toshiba
"Manufacturer_Part_Number" CMS04(TE12L,Q,M)
"Description" Schottky Diodes & Rectifiers Diode Schottky 30V 5A
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-DGA23/1390121.pdf
"Geometry.Height" 1.08mm
GATE 1 2 0
CMS04_TE12L_Q_M_
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
311198/449296/2.50/2/4/Diode
