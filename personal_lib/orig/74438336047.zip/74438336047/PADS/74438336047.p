*PADS-LIBRARY-PART-TYPES-V9*

74438336047 INDC3030X200N I IND 7 1 0 0 0
TIMESTAMP 2025.02.23.10.54.44
"Mouser Part Number" 710-74438336047
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/74438336047?qs=iC14BvcgY%2F3pMAWg8A9uRQ%3D%3D
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 74438336047
"Description" WE-MAPI SMD Shielded Power Inductor, 3020, 4.7uH
"Datasheet Link" http://katalog.we-online.de/pbs/datasheet/74438336047.pdf
"Geometry.Height" 2mm
GATE 1 2 0
74438336047
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
465233/449296/2.50/2/3/Inductor
