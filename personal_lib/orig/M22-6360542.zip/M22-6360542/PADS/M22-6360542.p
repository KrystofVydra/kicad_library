*PADS-LIBRARY-PART-TYPES-V9*

M22-6360542 M226360542 I CON 9 1 0 0 0
TIMESTAMP 2025.04.11.07.30.53
"Manufacturer_Name" Harwin
"Manufacturer_Part_Number" M22-6360542
"Mouser Part Number" 855-M22-6360542
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Harwin/M22-6360542?qs=DZ5lKmO5UoHsEkqeKSGabg%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Headers & Wire Housings 5+5 DIL SMT SOCKET LOW PROFILE
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/M22-6360542.pdf
"Geometry.Height" 2.15mm
GATE 1 10 0
M22-6360542
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10

*END*
*REMARK* SamacSys ECAD Model
324235/449296/2.50/10/4/Connector
