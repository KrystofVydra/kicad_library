*PADS-LIBRARY-PART-TYPES-V9*

LIS3DHTR LIS3DHTR I ANA 7 1 0 0 0
TIMESTAMP 2025.05.26.13.45.59
"Mouser Part Number" 511-LIS3DHTR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/LIS3DHTR?qs=6la6oa3D8xzhXYax3cEo4w%3D%3D
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" LIS3DHTR
"Description" Accelerometer 3-Axis 2g/16g 1.8V LGA16 STMicroelectronics LIS3DHTR Accelerometer IC, 3-axis, I2C, SPI 1.71  3.6 V, 16-Pin LGA
"Datasheet Link" http://www.st.com/content/ccc/resource/technical/document/datasheet/3c/ae/50/85/d6/b1/46/fe/CD00274221.pdf/files/CD00274221.pdf/jcr:content/translations/en.CD00274221.pdf
"Geometry.Height" 1mm
GATE 1 16 0
LIS3DHTR
1 0 P VDDIO
2 0 U NC_1
3 0 U NC_2
4 0 U SCL/SPC
5 0 G GND_1
6 0 U SDA/SDI/SDO
7 0 U SDO/SA0
8 0 L CS
9 0 L INT2
10 0 U RES
11 0 L INT1
12 0 G GND_2
13 0 U ADC3
14 0 P VDD
15 0 U ADC2
16 0 U ADC1

*END*
*REMARK* SamacSys ECAD Model
221833/449296/2.50/16/4/Accelerometer
