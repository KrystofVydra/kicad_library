*PADS-LIBRARY-PART-TYPES-V9*

16SVPF560M 16SVPT560M I CAP 7 1 0 0 0
TIMESTAMP 2025.03.19.09.07.36
"Mouser Part Number" 667-16SVPF560M
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Panasonic/16SVPF560M?qs=OE1iw1LrrPECh7dXtCZMuA%3D%3D
"Manufacturer_Name" Panasonic
"Manufacturer_Part_Number" 16SVPF560M
"Description" Aluminum Organic Polymer Capacitors 16volts 560uF ESR 14mohm
"Datasheet Link" http://industrial.panasonic.com/cdbs/www-data/pdf/AAB8000/AAB8000C177.pdf
"Geometry.Height" 12mm
GATE 1 2 0
16SVPF560M
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
11655140/449296/2.50/2/2/Capacitor Polarised
