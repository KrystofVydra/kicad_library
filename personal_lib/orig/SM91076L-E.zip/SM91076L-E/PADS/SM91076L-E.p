*PADS-LIBRARY-PART-TYPES-V9*

SM91076L-E SOIC127P950X610-16N I XFR 9 1 0 0 0
TIMESTAMP 2025.03.10.15.19.50
"Manufacturer_Name" Bourns
"Manufacturer_Part_Number" SM91076L-E
"Mouser Part Number" 652-SM91076L-E
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Bourns/SM91076L-E?qs=Wj%2FVkw3K%252BMBmgob17aXHHQ%3D%3D
"Arrow Part Number" SM91076L-E
"Arrow Price/Stock" https://www.arrow.com/en/products/sm91076l-e/bourns?region=nac
"Description" 10/100 Base-T Transformer
"Datasheet Link" https://d3i3tjh2mutzs2.cloudfront.net/public/catalog/ebook_image/581515/3/0.jpg
"Geometry.Height" 6.1mm
GATE 1 16 0
SM91076L-E
1 0 U TD+
2 0 U TCT
3 0 U TD-
4 0 U NO_CONNECT_1
5 0 U NO_CONNECT_2
6 0 U RD+
7 0 U RCT
8 0 U RD-
16 0 U TX+
15 0 U CMT_2
14 0 U TX-
13 0 U NO_CONNECT_4
12 0 U NO_CONNECT_3
11 0 U RX+
10 0 U CMT_1
9 0 U RX-

*END*
*REMARK* SamacSys ECAD Model
14972493/449296/2.50/16/2/Transformer
