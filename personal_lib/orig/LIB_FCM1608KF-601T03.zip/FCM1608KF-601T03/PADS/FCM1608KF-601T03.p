*PADS-LIBRARY-PART-TYPES-V9*

FCM1608KF-601T03 BEADC1608X95N I ANA 9 1 0 0 0
TIMESTAMP 2025.02.23.13.33.36
"Manufacturer_Name" TAI-TECH
"Manufacturer_Part_Number" FCM1608KF-601T03
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Ferrite Chip Bead(Lead Free)
"Datasheet Link" https://www.tai-tech.com.tw/_upload/files/FCM1608-Series.pdf
"Geometry.Height" 0.95mm
GATE 1 2 0
FCM1608KF-601T03
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
1298916/449296/2.50/2/4/Ferrite Bead
