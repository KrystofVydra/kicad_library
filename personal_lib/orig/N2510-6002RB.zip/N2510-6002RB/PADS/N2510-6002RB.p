*PADS-LIBRARY-PART-TYPES-V9*

N2510-6002RB SHDR10W64P254_2X5_2002X859X991P I CON 9 1 0 0 0
TIMESTAMP 2025.02.28.17.23.09
"Manufacturer_Name" 3M
"Manufacturer_Part_Number" N2510-6002RB
"Mouser Part Number" 517-N2510-6002RB
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/3M-Electronic-Solutions-Division/N2510-6002RB?qs=QV10cN0MjFtispGaro3M2Q%3D%3D
"Arrow Part Number" N2510-6002RB
"Arrow Price/Stock" https://www.arrow.com/en/products/n2510-6002-rb/3m?region=europe
"Description" 3M 10W ST BOX HDR CLASS 2 3M 2500 Series, 2.54mm Pitch 10 Way 2 Row Straight PCB Header, Solder Termination, 2A
"Datasheet Link" http://multimedia.3m.com/mws/media/330367O/3mtm-100-in-4-wall-hdr-rohs-lp-straightra-hitemp-ts0770.pdf?fn=TS0770.pdf
"Geometry.Height" 9.91mm
GATE 1 10 0
N2510-6002RB
1 0 U 1
3 0 U 3
5 0 U 5
7 0 U 7
9 0 U 9
2 0 U 2
4 0 U 4
6 0 U 6
8 0 U 8
10 0 U 10

*END*
*REMARK* SamacSys ECAD Model
242297/449296/2.50/10/3/Connector
