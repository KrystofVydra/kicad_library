*PADS-LIBRARY-PART-TYPES-V9*

21033812802 21033812802 I CON 9 1 0 0 0
TIMESTAMP 2025.03.14.12.20.05
"Manufacturer_Name" HARTING
"Manufacturer_Part_Number" 21033812802
"Mouser Part Number" 617-21033812802
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/HARTING/21033812802?qs=%252BTm8HPXHDaL2upFz%252BjeJnw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" M12 X-code 8pin female PCB with front panel mounting, straight, Cat6A  (w/ housing 21033012003)
"Datasheet Link" https://b2b.harting.com/files/download/PRD/PDF_DS/PDF_DS_21033812802_EN.pdf
"Geometry.Height" 25.1mm
GATE 1 8 0
21033812802
1 0 U TD1+
2 0 U RD1-
3 0 U TD2+
4 0 U RD2-
5 0 U TD4+
6 0 U RD4-
7 0 U RD3-
8 0 U TD3+

*END*
*REMARK* SamacSys ECAD Model
2455374/449296/2.50/8/2/Connector
