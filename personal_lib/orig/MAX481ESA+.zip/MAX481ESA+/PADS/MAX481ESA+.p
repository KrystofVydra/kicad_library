*PADS-LIBRARY-PART-TYPES-V9*

MAX481ESA+ SOIC127P600X175-8N I ANA 7 1 0 0 0
TIMESTAMP 2025.02.25.14.09.22
"Mouser Part Number" 700-MAX481ESA
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Analog-Devices-Maxim-Integrated/MAX481ESA%2b?qs=1THa7WoU59ElcTNgoHBImQ%3D%3D
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" MAX481ESA+
"Description" MAX481ESA+, Line Transceiver, RS-485, RS-422 2.5Mbit/s Differential, 4.75  5.25 V, 8-Pin SOIC
"Datasheet Link" http://datasheets.maximintegrated.com/en/ds/MAX1487-MAX491.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
MAX481ESA+
1 0 S RO
2 0 L \RE
3 0 L DE
4 0 L DI
8 0 P VCC
7 0 B B
6 0 B A
5 0 P GND

*END*
*REMARK* SamacSys ECAD Model
1297/449296/2.50/8/3/Integrated Circuit
