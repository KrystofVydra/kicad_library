*PADS-LIBRARY-PART-TYPES-V9*

SRN6045-1R0Y SRN60451R0Y I IND 7 1 0 0 0
TIMESTAMP 2025.03.27.08.02.53
"Mouser Part Number" 652-SRN6045-1R0Y
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Bourns/SRN6045-1R0Y?qs=opBjA1TV902RZfzjK85pyQ%3D%3D
"Manufacturer_Name" Bourns
"Manufacturer_Part_Number" SRN6045-1R0Y
"Description" Bourns SRN6045 Series Shielded Wire-wound SMD Inductor with a Ferrite Core, 1 uH +/-30% 8.5A Idc
"Datasheet Link" 
"Geometry.Height" 4.5mm
GATE 1 2 0
SRN6045-1R0Y
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
390190/449296/2.50/2/4/Inductor
