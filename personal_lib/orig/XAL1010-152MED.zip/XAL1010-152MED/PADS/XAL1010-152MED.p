*PADS-LIBRARY-PART-TYPES-V9*

XAL1010-152MED XAL1010152MED I IND 7 1 0 0 0
TIMESTAMP 2025.03.19.08.34.15
"Mouser Part Number" 994-XAL1010-152MED
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Coilcraft/XAL1010-152MED?qs=zCSbvcPd3pYs9EPvUQpI8A%3D%3D
"Manufacturer_Name" COILCRAFT
"Manufacturer_Part_Number" XAL1010-152MED
"Description" Fixed Inductors 1.5uH Shld 20% 40.5A 1.76mOhms AECQ2
"Datasheet Link" https://www.mouser.de/datasheet/2/597/xal1010-270716.pdf
"Geometry.Height" 10mm
GATE 1 2 0
XAL1010-152MED
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
1728741/449296/2.50/2/4/Inductor
