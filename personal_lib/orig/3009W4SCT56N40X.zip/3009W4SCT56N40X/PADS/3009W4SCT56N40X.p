*PADS-LIBRARY-PART-TYPES-V9*

3009W4SCT56N40X 3009W4SCT56N40X I CON 9 1 0 0 0
TIMESTAMP 2025.03.11.09.25.10
"Manufacturer_Name" CONEC
"Manufacturer_Part_Number" 3009W4SCT56N40X
"Mouser Part Number" 706-3009W4SCT56N40X
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=706-3009W4SCT56N40X
"Arrow Part Number" 3009W4SCT56N40X
"Arrow Price/Stock" https://www.arrow.com/en/products/3009w4sct56n40x/conec?region=nac
"Description" D-Sub Mixed Contact Connectors 9W4 SOLDER CUP FEMALE R/A 20 AMP
"Datasheet Link" https://media.digikey.com/pdf/Data%20Sheets/Conec%20PDFs/3009W4SCT56N40X.pdf
"Geometry.Height" 12.93mm
GATE 1 11 0
3009W4SCT56N40X
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
A1 0 U A1
A2 0 U A2
A3 0 U A3
A4 0 U A4
MH1 0 U MH1
MH2 0 U MH2

*END*
*REMARK* SamacSys ECAD Model
1168762/449296/2.50/11/3/Connector
