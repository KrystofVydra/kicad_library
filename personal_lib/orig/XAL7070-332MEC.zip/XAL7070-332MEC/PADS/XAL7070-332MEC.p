*PADS-LIBRARY-PART-TYPES-V9*

XAL7070-332MEC XAL7070332MEC I IND 7 1 0 0 0
TIMESTAMP 2025.02.23.12.11.03
"Mouser Part Number" 994-XAL7070-332MEC
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Coilcraft/XAL7070-332MEC?qs=zCSbvcPd3pYy2mgyZPJrOA%3D%3D
"Manufacturer_Name" COILCRAFT
"Manufacturer_Part_Number" XAL7070-332MEC
"Description" Power Inductors - SMD 3.3uH Shld 20% 15.1A 9.42mOhms AECQ2
"Datasheet Link" https://www.coilcraft.com/getmedia/1ba55433-bcc8-4838-9b21-382f497e12e0/xal7070.pdf
"Geometry.Height" 7mm
GATE 1 2 0
XAL7070-332MEC
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
850505/449296/2.50/2/3/Inductor
