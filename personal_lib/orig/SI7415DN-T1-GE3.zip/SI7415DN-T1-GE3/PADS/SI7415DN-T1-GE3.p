*PADS-LIBRARY-PART-TYPES-V9*

SI7415DN-T1-GE3 SQ7414AENT1GE3 I TRX 6 1 0 0 0
TIMESTAMP 2025.02.23.15.07.56
"Mouser Part Number" 781-SI7415DN-T1-GE3
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Vishay-Semiconductors/SI7415DN-T1-GE3?qs=tWM4QuTcS4Wt96olzJyuKQ%3D%3D
"Manufacturer_Name" Vishay
"Manufacturer_Part_Number" SI7415DN-T1-GE3
"Description" VISHAY - SI7415DN-T1-GE3 - MOSFET, P CH, 60V, 3.6A, PPAK SO8
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-DGA23/1580926.pdf
GATE 1 8 0
SI7415DN-T1-GE3
1 0 U S_1
2 0 U S_2
3 0 U S_3
4 0 U G
5 0 U D_1
6 0 U D_2
7 0 U D_3
8 0 U D_4

*END*
*REMARK* SamacSys ECAD Model
739262/449296/2.50/8/4/MOSFET (P-Channel)
