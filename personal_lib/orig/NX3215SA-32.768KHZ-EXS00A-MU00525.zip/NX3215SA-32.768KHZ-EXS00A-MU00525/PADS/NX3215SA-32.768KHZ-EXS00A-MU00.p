*PADS-LIBRARY-PART-TYPES-V9*

NX3215SA-32.768KHZ-EXS00A-MU00 NX3215SA32768KHZEXS00AMU00525 I OSC 9 1 0 0 0
TIMESTAMP 2025.02.23.14.04.18
"Manufacturer_Name" NDK
"Manufacturer_Part_Number" NX3215SA-32.768KHZ-EXS00A-MU00525
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" CRYSTAL 32.768KHZ 6PF SMD
"Datasheet Link" https://www.ndk.com/en/products/search/crystal/1188854_1494.html
"Geometry.Height" 0.9mm
GATE 1 2 0
NX3215SA-32.768KHZ-EXS00A-MU00
2 0 U X2

*END*
*REMARK* SamacSys ECAD Model
1297254/449296/2.50/2/4/Crystal or Oscillator
