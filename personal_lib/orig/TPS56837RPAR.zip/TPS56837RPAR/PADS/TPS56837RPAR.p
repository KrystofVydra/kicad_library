*PADS-LIBRARY-PART-TYPES-V9*

TPS56837RPAR TPS56A37RPAR I ANA 7 1 0 0 0
TIMESTAMP 2025.02.23.11.21.55
"Mouser Part Number" 595-TPS56837RPAR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS56837RPAR?qs=ST9lo4GX8V2enNako9KoBQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS56837RPAR
"Description" 8-A Synchronous Buck Converter
"Datasheet Link" https://www.ti.com/lit/gpn/tps56837
"Geometry.Height" 1mm
GATE 1 13 0
TPS56837RPAR
1 0 U EN
2 0 U FB
3 0 U AGND
4 0 U PG
5 0 U SS
6 0 U SW
7 0 U BOOT
8 0 U VIN_1
9 0 U PGND
10 0 U MODE
11 0 U VIN_2
12 0 U VIN_3
13 0 U VIN_4

*END*
*REMARK* SamacSys ECAD Model
18677676/449296/2.50/13/4/Integrated Circuit
