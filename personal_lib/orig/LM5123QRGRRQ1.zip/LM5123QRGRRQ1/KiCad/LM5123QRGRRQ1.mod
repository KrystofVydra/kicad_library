PCBNEW-LibModule-V1  2025-03-19 07:12:42
# encoding utf-8
Units mm
$INDEX
QFN50P350X350X100-21N-D
$EndINDEX
$MODULE QFN50P350X350X100-21N-D
Po 0 0 0 15 67da6e6a 00000000 ~~
Li QFN50P350X350X100-21N-D
Cd RGR (S-PVQFN-N20)_2020
Kw Integrated Circuit
Sc 0
At SMD
AR 
Op 0 0 0
T0 0 0 1.27 1.27 0 0.254 N V 21 N "IC**"
T1 0 0 1.27 1.27 0 0.254 N I 21 N "QFN50P350X350X100-21N-D"
DS -2.4 -2.4 2.4 -2.4 0.05 24
DS 2.4 -2.4 2.4 2.4 0.05 24
DS 2.4 2.4 -2.4 2.4 0.05 24
DS -2.4 2.4 -2.4 -2.4 0.05 24
DS -1.75 -1.75 1.75 -1.75 0.1 24
DS 1.75 -1.75 1.75 1.75 0.1 24
DS 1.75 1.75 -1.75 1.75 0.1 24
DS -1.75 1.75 -1.75 -1.75 0.1 24
DS -1.75 -1.25 -1.25 -1.75 0.1 24
DC -2.15 -1.75 -2.025 -1.75 0.254 21
$PAD
Po -1.7 -1
Sh "1" R 0.3 0.9 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.7 -0.5
Sh "2" R 0.3 0.9 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.7 0
Sh "3" R 0.3 0.9 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.7 0.5
Sh "4" R 0.3 0.9 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.7 1
Sh "5" R 0.3 0.9 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1 1.7
Sh "6" R 0.3 0.9 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 1.7
Sh "7" R 0.3 0.9 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 1.7
Sh "8" R 0.3 0.9 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 1.7
Sh "9" R 0.3 0.9 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1 1.7
Sh "10" R 0.3 0.9 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.7 1
Sh "11" R 0.3 0.9 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.7 0.5
Sh "12" R 0.3 0.9 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.7 0
Sh "13" R 0.3 0.9 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.7 -0.5
Sh "14" R 0.3 0.9 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.7 -1
Sh "15" R 0.3 0.9 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1 -1.7
Sh "16" R 0.3 0.9 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -1.7
Sh "17" R 0.3 0.9 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 -1.7
Sh "18" R 0.3 0.9 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -1.7
Sh "19" R 0.3 0.9 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1 -1.7
Sh "20" R 0.3 0.9 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 0
Sh "21" R 2.15 2.15 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$EndMODULE QFN50P350X350X100-21N-D
$EndLIBRARY
