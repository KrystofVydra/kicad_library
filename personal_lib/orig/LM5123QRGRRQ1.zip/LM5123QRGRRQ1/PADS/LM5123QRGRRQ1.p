*PADS-LIBRARY-PART-TYPES-V9*

LM5123QRGRRQ1 QFN50P350X350X100-21N-D I ANA 7 1 0 0 0
TIMESTAMP 2025.03.19.07.12.42
"Mouser Part Number" 595-LM5123QRGRRQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/LM5123QRGRRQ1?qs=doiCPypUmgE7PahXWUfmIQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LM5123QRGRRQ1
"Description" Texas Instruments
"Datasheet Link" https://www.ti.com.cn/cn/lit/ds/symlink/lm51231-q1.pdf?ts=1669103299917&ref_url=https%253A%252F%252Fwww.ti.com.cn%252Fproduct%252Fcn%252FLM51231-Q1
"Geometry.Height" 1mm
GATE 1 21 0
LM5123QRGRRQ1
1 0 U CSP
2 0 U CSN
3 0 U VOUT/SENSE
4 0 U PGOOD
5 0 U HO
6 0 U SW
7 0 U HB
8 0 U BIAS
9 0 U VCC
10 0 U PGND
15 0 U RT
14 0 U SYNC/DITHER/VH
13 0 U UVLO/EN
12 0 U MODE
11 0 U LO
21 0 U EP
20 0 U COMP
19 0 U AGND
18 0 U TRK
17 0 U SS
16 0 U VREF/_RANGE

*END*
*REMARK* SamacSys ECAD Model
17138229/449296/2.50/21/3/Integrated Circuit
