*PADS-LIBRARY-PART-TYPES-V9*

21033812824 21033812824 I CON 9 1 0 0 0
TIMESTAMP 2025.03.14.11.41.09
"Manufacturer_Name" HARTING
"Manufacturer_Part_Number" 21033812824
"Mouser Part Number" 617-21033812824
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/HARTING/21033812824?qs=T3oQrply3y8z62%2FVU7QakA%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" M12 X-code 8pin female straight pcb connector, SMT, w/ transformer, 1Gbit, shielded, PoE enabled (w/ housing 21033012006)
"Datasheet Link" https://b2b.harting.com/files/download/PRD/PDF_DS/PDF_DS_21033810102.pdf
"Geometry.Height" 24.8mm
GATE 1 17 0
21033812824
P1 0 U D2+
P2 0 U D2-
P3 0 U CT3
P4 0 U D3+
P5 0 U D3-
P6 0 U CT1
P7 0 U D1+
P8 0 U D1-
P9 0 U GND
P10 0 U VC1
P11 0 U VC2
P12 0 U VC3
P13 0 U VC4
P14 0 U CT4
P15 0 U D4-
P16 0 U D4+
P17 0 U CT2

*END*
*REMARK* SamacSys ECAD Model
2455397/449296/2.50/17/2/Connector
