*PADS-LIBRARY-PART-TYPES-V9*

RFD3055LESM9A FQD1N80TM I TRX 7 1 0 0 0
TIMESTAMP 2025.02.23.09.22.48
"Mouser Part Number" 512-RFD3055LESM9A
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/onsemi-Fairchild/RFD3055LESM9A?qs=cnIeywgme7Z76wawIlx3bQ%3D%3D
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" RFD3055LESM9A
"Description" Peak Current vs Pulse Width Curve; Temperature Compensating PSPICE Model; Related Literature - TB334 Guidelines for Soldering Surface MountComponents to PC Boards; UIS Rating Curve; 11A, 60V; rDS(ON)= 0.107
"Datasheet Link" https://www.onsemi.com/pub/Collateral/RFD3055LESM-D.pdf
"Geometry.Height" 2.39mm
GATE 1 3 0
RFD3055LESM9A
1 0 U G
2 0 U D
3 0 U S

*END*
*REMARK* SamacSys ECAD Model
969222/449296/2.50/3/2/MOSFET (N-Channel)
