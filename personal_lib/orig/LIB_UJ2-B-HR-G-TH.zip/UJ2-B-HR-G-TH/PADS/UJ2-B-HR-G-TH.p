*PADS-LIBRARY-PART-TYPES-V9*

UJ2-B-HR-G-TH UJ2BHRGTH I CON 7 1 0 0 0
TIMESTAMP 2026.01.29.09.29.11
"Mouser Part Number" 179-UJ2-B-HR-G-TH
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Same-Sky/UJ2-B-HR-G-TH?qs=HoCaDK9Nz5cuzuu5C%2FN7nw%3D%3D
"Manufacturer_Name" Same Sky
"Manufacturer_Part_Number" UJ2-B-HR-G-TH
"Description" Type B, USB 2.0, 480 Mbps, 5 Vdc, 1.5 A, Right Angle, Through Hole, Board Lock, 0.6 in Plating Thickness, Black Insulator, Pick & Place, USB Receptacle
"Datasheet Link" https://www.sameskydevices.com/product/resource/uj2-b-hr-g-th.pdf
"Geometry.Height" 11.1mm
GATE 1 6 0
UJ2-B-HR-G-TH
1 0 U VBUS
2 0 U D-
3 0 U D+
4 0 U GND
5 0 U SHIELD_1
6 0 U SHIELD_2

*END*
*REMARK* SamacSys ECAD Model
18916413/449296/2.50/6/2/Connector
