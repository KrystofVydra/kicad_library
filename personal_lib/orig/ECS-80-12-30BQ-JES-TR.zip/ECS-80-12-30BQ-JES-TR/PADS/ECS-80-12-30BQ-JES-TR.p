*PADS-LIBRARY-PART-TYPES-V9*

ECS-80-12-30BQ-JES-TR ECS801230BQJESTR I OSC 9 1 0 0 0
TIMESTAMP 2025.04.02.10.20.53
"Manufacturer_Name" ECS
"Manufacturer_Part_Number" ECS-80-12-30BQ-JES-TR
"Mouser Part Number" 520-8012-30BQ-JES-TR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ECS/ECS-80-12-30BQ-JES-TR?qs=stqOd1AaK78kdaHjm9QlCw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Crystals ECX-53BQ 8.000 MHz 12 pF 5032 4 pad AECQ +/-20/50 ppm -40 - +125C 100ohm Max ESR (l*w*h) (5*3.2*0.85)
"Datasheet Link" https://ecsxtal.com/store/pdf/ECX-53BQ.pdf?x96774
"Geometry.Height" 0.85mm
GATE 1 4 0
ECS-80-12-30BQ-JES-TR
1 0 U IN/OUT
2 0 U GND_1
3 0 U OUT/IN
4 0 U GND_2

*END*
*REMARK* SamacSys ECAD Model
13927489/449296/2.50/4/3/Crystal or Oscillator
