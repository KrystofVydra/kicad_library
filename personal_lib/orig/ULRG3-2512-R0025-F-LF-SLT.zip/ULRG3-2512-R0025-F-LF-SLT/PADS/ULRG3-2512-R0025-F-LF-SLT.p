*PADS-LIBRARY-PART-TYPES-V9*

ULRG3-2512-R0025-F-LF-SLT RESC6430X80N I RES 7 1 0 0 0
TIMESTAMP 2025.02.28.08.13.54
"Mouser Part Number" 66-ULRG3-2512-R0025F
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/IRC-TT-Electronics/ULRG3-2512-R0025-F-LF-SLT?qs=o5%2FBfEwRdct74ZqhFb2BFA%3D%3D
"Manufacturer_Name" IRC / TT Electronics
"Manufacturer_Part_Number" ULRG3-2512-R0025-F-LF-SLT
"Description" Current Sense Resistors - SMD Metal Element CS Resistor AEC-Q200
"Datasheet Link" https://www.ttelectronics.com/TTElectronics/media/ProductFiles/Datasheet/ULR.pdf
"Geometry.Height" 0.8mm
GATE 1 2 0
ULRG3-2512-R0025-F-LF-SLT
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
4351664/449296/2.50/2/3/Resistor
