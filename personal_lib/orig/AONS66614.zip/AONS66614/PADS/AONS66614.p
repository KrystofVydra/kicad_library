*PADS-LIBRARY-PART-TYPES-V9*

AONS66614 AON6482 I TRX 9 1 0 0 0
TIMESTAMP 2025.07.10.16.29.24
"Manufacturer_Name" Alpha & Omega Semiconductors
"Manufacturer_Part_Number" AONS66614
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" 60V N-Channel AlphaSGT TM
"Datasheet Link" https://4donline.ihs.com/images/VipMasterIC/IC/ALOM/ALOM-S-A0020443660/ALOM-S-A0020443776-1.pdf?hkey=EF798316E3902B6ED9A73243A3159BB0
"Geometry.Height" 1.05mm
GATE 1 9 0
AONS66614
1 0 U S_1
2 0 U S_2
3 0 U S_3
4 0 U G
5 0 U D_1
6 0 U D_2
7 0 U D_3
8 0 U D_4
9 0 U D_5

*END*
*REMARK* SamacSys ECAD Model
19908005/449296/2.50/9/4/MOSFET (N-Channel)
