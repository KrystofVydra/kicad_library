*PADS-LIBRARY-PART-TYPES-V9*

SCMT22D505PRBB0 SCMT22D505PRBB0 I CAP 7 1 0 0 0
TIMESTAMP 2025.05.26.14.35.19
"Mouser Part Number" 581-SCMT22D505PRBB0
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/KYOCERA-AVX/SCMT22D505PRBB0?qs=qSfuJ%252Bfl%2Fd7eu7l2uG1%252Biw%3D%3D
"Manufacturer_Name" Kyocera AVX
"Manufacturer_Part_Number" SCMT22D505PRBB0
"Description" AVX 5F Supercapacitor 5.4V dc, Through Hole
"Datasheet Link" 
"Geometry.Height" 23.5mm
GATE 1 2 0
SCMT22D505PRBB0
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
1488845/449296/2.50/2/4/Capacitor Polarised
