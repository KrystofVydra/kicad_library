*PADS-LIBRARY-PART-TYPES-V9*

T498C476K016ATE500 T498C I CAP 7 1 0 0 0
TIMESTAMP 2025.03.27.07.03.29
"Mouser Part Number" 80-T498C476K16ATE500
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/KEMET/T498C476K016ATE500?qs=AKSBOA7TyGBmFJubA1phMA%3D%3D
"Manufacturer_Name" KEMET
"Manufacturer_Part_Number" T498C476K016ATE500
"Description" T498, Tantalum, MnO2 Tantalum, High Temperature, 47 uF, 10%, 16 VDC, 150C, -55C, 85C, SMD, MnO2, Molded, Hi-Temp, 150C, Auto, AEC-Q200, 4.5 % , N/A, 500 mOhms, 7500 nA, 224.48 mg, 6032, 2.5mm, Height Max = 2.8mm, 500, 156  Weeks
"Datasheet Link" https://content.kemet.com/datasheets/KEM_T2053_T498_AUTO.pdf
"Geometry.Height" 2.8mm
GATE 1 2 0
T498C476K016ATE500
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
1021555/449296/2.50/2/2/Capacitor Polarised
