*PADS-LIBRARY-PART-TYPES-V9*

KO_EELP41.22-Q1S2-25-A8J8-020- KOEELP4122Q1S225A8J8020R18 I DIO 7 1 0 0 0
TIMESTAMP 2025.03.19.06.22.55
"Mouser Part Number" 720-P412Q1S225A8J802
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ams-OSRAM/KO-EELP41.22-Q1S2-25-A8J8-020-R18?qs=ZcfC38r4PoswH9uD%2FZTNyw%3D%3D
"Manufacturer_Name" ams OSRAM
"Manufacturer_Part_Number" KO EELP41.22-Q1S2-25-A8J8-020-R18
"Description" LED, InGaAlP, Orange, SMD, 0603 [1608 Metric], 20 mA, 2 V, 605 nm
"Datasheet Link" https://look.ams-osram.com/m/6069422f8e1c569f/original/KO-EELP41-22.pdf
"Geometry.Height" 0.5mm
GATE 1 2 0
KO_EELP41.22-Q1S2-25-A8J8-020-
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
19979122/449296/2.50/2/3/LED
