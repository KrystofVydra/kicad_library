*PADS-LIBRARY-PART-TYPES-V9*

BQ25798RQMR BQ25798RQMR I ANA 9 1 0 0 0
TIMESTAMP 2025.03.18.15.25.54
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" BQ25798RQMR
"Mouser Part Number" 595-BQ25798RQMR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/BQ25798RQMR?qs=ljCeji4nMDmr66dwAbNsCg%3D%3D
"Arrow Part Number" BQ25798RQMR
"Arrow Price/Stock" https://www.arrow.com/en/products/bq25798rqmr/texas-instruments?utm_currency=USD&region=nac
"Description" Battery Management I C controlled, 1-4-cell, 5-A buck-boost solar battery charger with dual-input selector and MPPT
"Datasheet Link" https://www.ti.com/lit/gpn/bq25798
"Geometry.Height" 1mm
GATE 1 33 0
BQ25798RQMR
1 0 U STAT_1
2 0 U VBUS_1
3 0 U VBUS_2
4 0 U BTST1
5 0 U REGN
6 0 U D+
7 0 U D-
8 0 U VAC2
9 0 U VAC1_1
10 0 U ACDRV2
11 0 U ACDRV1
12 0 U \QON
13 0 U \CE
14 0 U SCL
15 0 U SDA
16 0 U TS_1
17 0 U ILIM_HIZ
18 0 U BATP
19 0 U BTST2
20 0 U PROG
21 0 U \INT
22 0 U BAT_1
23 0 U BAT_2
24 0 U SDRV_1
25 0 U SYS
26 0 U SW2
27 0 U GND
28 0 U SW1
29 0 U PMID
30 0 U STAT_2
31 0 U VAC1_2
32 0 U TS_2
33 0 U SDRV_2

*END*
*REMARK* SamacSys ECAD Model
14918031/449296/2.50/33/3/Integrated Circuit
