*PADS-LIBRARY-PART-TYPES-V9*

1424180 1424180 I CON 9 1 0 0 0
TIMESTAMP 2025.03.10.11.29.51
"Manufacturer_Name" Phoenix Contact
"Manufacturer_Part_Number" 1424180
"Mouser Part Number" 651-1424180
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Phoenix-Contact/1424180?qs=AdTq2PFIamludhAMwBa3%2Fw%3D%3D
"Arrow Part Number" 1424180
"Arrow Price/Stock" https://www.arrow.com/en/products/1424180/phoenix-contact
"Description" Device connector, rear mounting, Ethernet CAT6A (10 Gbps), 8-position, Flush-type female connector,  straight, M12, coding: X - data , Rear mounting, Wave soldering contacts,  Alternative product in accordance with RoHS II without Exemption6c (Pb<0.1%) item no.: 1237389
"Datasheet Link" http://www.phoenixcontact.com/de/produkte/1424180
"Geometry.Height" 14mm
GATE 1 9 0
1424180
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9

*END*
*REMARK* SamacSys ECAD Model
658632/449296/2.50/9/6/Connector
